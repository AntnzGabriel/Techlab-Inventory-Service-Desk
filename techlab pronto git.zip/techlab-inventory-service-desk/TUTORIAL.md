# Tutorial explicado — TechLab Inventory & Service Desk

Este guia acompanha a implementação das Aulas 08 e 09. A ideia não é apenas copiar código: é entender por que cada parte existe e como as classes trabalham juntas.

## 1. O que o sistema resolve

O TechLab Inventory registra ativos de TI (notebooks, servidores e estações) e chamados de suporte relacionados a esses ativos. Os dados ficam em um banco SQLite, então continuam disponíveis depois que o programa termina.

Na Aula 08, o foco é conectar Java ao banco e persistir ativos. Na Aula 09, o projeto ganha o CRUD completo, chamados relacionados aos ativos e consultas com JOIN.

## 2. Como o projeto está organizado

```text
src/main/java/br/com/techlab/
├── config/ConexaoBanco.java
├── dao/AtivoDAO.java
├── dao/ChamadoDAO.java
├── model/AtivoTI.java
├── model/ChamadoSuporte.java
└── Main.java
src/main/resources/schema.sql
```

- `model`: representa as entidades do problema. `AtivoTI` e `ChamadoSuporte` são objetos Java, sem responsabilidade de executar SQL.
- `dao`: significa Data Access Object. É a camada que sabe salvar, consultar, atualizar e excluir dados. Assim, a regra principal do programa não fica misturada com comandos SQL.
- `config`: concentra a configuração e a abertura da conexão com o banco.
- `Main`: demonstra o fluxo completo da aplicação.
- `schema.sql`: documenta a estrutura das tabelas do SQLite.

Essa separação facilita manutenção: se a forma de acessar o banco mudar, a maior parte da aplicação não precisa conhecer os detalhes.

## 3. Preparar o ambiente

1. Instale o JDK 17 ou superior.
2. Instale o Visual Studio Code e a extensão **Extension Pack for Java**.
3. Tenha o Maven instalado e disponível no terminal (`mvn -version`).
4. Extraia o ZIP e abra no VS Code a pasta que contém o arquivo `pom.xml`.

O `pom.xml` declara Java 17 e a dependência `sqlite-jdbc`. O Maven baixa essa biblioteca para o projeto. Por isso, não é necessário baixar e adicionar manualmente um `.jar`.

## 4. Entender a conexão: `ConexaoBanco.java`

A URL `jdbc:sqlite:techlab.db` informa ao driver que será usado SQLite e que o arquivo do banco se chama `techlab.db`.

`DriverManager.getConnection(URL)` abre uma conexão. O método `obterConexao()` centraliza essa operação para que os DAOs não precisem repetir a URL.

O SQLite exige que a verificação de chaves estrangeiras seja ativada em cada conexão. Por isso, logo depois de abrir a conexão, executamos `PRAGMA foreign_keys = ON;`. Sem isso, o banco pode não impedir referências inválidas.

`inicializarBanco()` executa `CREATE TABLE IF NOT EXISTS`. O `IF NOT EXISTS` permite iniciar o programa várias vezes sem tentar recriar tabelas que já existem.

## 5. Entender as tabelas e o relacionamento

A tabela `ativos` guarda os equipamentos. Seu `id` é a chave primária, gerada automaticamente. `patrimonio` é `UNIQUE` porque cada ativo precisa ter um código patrimonial exclusivo. Campos obrigatórios usam `NOT NULL`.

A tabela `chamados` guarda as solicitações de suporte. A coluna `ativo_id` é uma chave estrangeira que aponta para `ativos(id)`. Isso representa o relacionamento: um ativo pode possuir vários chamados, e cada chamado aponta para um ativo.

O projeto usa `ON DELETE RESTRICT`: o banco recusa a exclusão de um ativo enquanto houver chamados ligados a ele. Essa escolha corresponde à demonstração de integridade referencial da Aula 09. É diferente de `ON DELETE CASCADE`, que apagaria automaticamente os chamados filhos.

## 6. Por que usar `PreparedStatement`

Uma consulta como `WHERE patrimonio = ?` mantém o comando SQL separado do valor informado pelo usuário. O `?` é um parâmetro, preenchido com `setString`, `setInt` ou `setDouble`.

Isso evita montar SQL concatenando entradas. A concatenação pode permitir SQL Injection, quando um texto digitado é interpretado como parte do comando. Com `PreparedStatement`, os valores são tratados como dados.

Os índices dos parâmetros começam em 1. Portanto, `stmt.setString(1, patrimonio)` preenche o primeiro `?` da instrução.

## 7. Por que usar `try-with-resources`

Conexões, comandos e resultados ocupam recursos. O bloco `try (...)` fecha automaticamente os objetos ao terminar, mesmo se ocorrer uma exceção. Isso evita deixar conexões e cursores abertos.

`ResultSet` é usado para ler resultados de `SELECT`. O `while (rs.next())` avança linha por linha. `executeQuery()` é para consultas; `executeUpdate()` é para `INSERT`, `UPDATE` e `DELETE`.

## 8. O papel dos DAOs

### `AtivoDAO`

- `salvar`: insere patrimônio, nome, categoria, detalhe e valor.
- `listarTodos`: consulta os ativos e converte cada linha em `AtivoTI`.
- `buscarPorPatrimonio`: procura um ativo pelo código único. O retorno `Optional` representa claramente a possibilidade de não encontrar resultado.
- `atualizar`: modifica os campos do ativo usando o ID no `WHERE`.
- `excluir`: primeiro verifica se existem chamados associados. Se houver, lança `SQLException` com a regra de negócio. Se não houver, executa o `DELETE`.

O retorno booleano de `atualizar` e `excluir` vem da quantidade de linhas afetadas. Maior que zero significa que um registro foi alterado/removido; zero significa que nenhum registro correspondeu ao ID.

### `ChamadoDAO`

- `salvar`: grava descrição, status e o ID do ativo associado.
- `listarPorAtivo`: filtra chamados pelo `ativo_id`. O ativo reconstruído aqui é uma referência leve, contendo principalmente o ID.
- `listarTodosComAtivo`: usa `INNER JOIN` para trazer os dados das duas tabelas e reconstruir um `AtivoTI` completo dentro de cada `ChamadoSuporte`.
- `excluir`: remove um chamado pelo seu ID.

O `JOIN` é necessário quando a tela ou relatório precisa mostrar também nome, patrimônio e categoria do ativo, e não apenas seu identificador.

## 9. Executar o projeto

Abra o terminal integrado do VS Code na pasta onde está o `pom.xml` e rode:

```bash
mvn clean compile
mvn exec:java -Dexec.mainClass="br.com.techlab.Main"
```

O primeiro comando limpa arquivos de compilação antigos e compila o código. O segundo executa a classe principal. Na primeira execução, o SQLite cria `techlab.db` e as tabelas.

A demonstração cadastra um ativo com patrimônio gerado para aquela execução, consulta o registro salvo, abre um chamado, atualiza o ativo, lista chamados com `INNER JOIN` e tenta excluir o ativo ainda relacionado. A exclusão deve ser bloqueada. Em seguida, remove primeiro os chamados de teste e depois o ativo, respeitando a relação pai/filho.

## 10. Como interpretar erros comuns

- `mvn: command not found` ou não reconhecido: Maven não está instalado ou não está no PATH.
- `no suitable driver` / driver SQLite não encontrado: confira se o Maven conseguiu baixar a dependência e se a execução foi feita pelo Maven.
- `no such table`: a inicialização das tabelas não foi executada ou a aplicação está usando outro diretório/banco.
- `FOREIGN KEY constraint failed`: algum chamado aponta para um ativo inexistente ou houve tentativa de excluir um ativo ainda relacionado.
- Patrimônio duplicado: a coluna tem restrição `UNIQUE`; cadastre outro código.

## 11. Enviar para o GitHub

Antes de enviar, confira os arquivos e não versione o banco local `techlab.db` nem a pasta `target/`; ambos são ignorados pelo `.gitignore`.

```bash
git status
git add .
git commit -m "feat: completa persistencia JDBC e CRUD do service desk"
git push origin main
```

Se ainda não houver repositório Git configurado, crie um repositório vazio no GitHub e configure o remoto uma única vez:

```bash
git init
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/techlab-inventory-service-desk.git
git push -u origin main
```

Troque `SEU-USUARIO` pelo seu usuário. Se a pasta já estiver conectada a um repositório, não repita `git init` nem `git remote add origin`.

## 12. O que foi consolidado entre as aulas

Os PDFs não usam exatamente o mesmo modelo de dados. A Aula 08 apresenta `categoria` e `detalhe_especifico` para os ativos e não inclui `status` no chamado. A Aula 09 apresenta `valor` no ativo e `status` no chamado. Este projeto mantém os campos das duas etapas para que uma implementação única cubra os dois roteiros.

A estrutura Maven e os pacotes `br.com.techlab` são uma organização do projeto entregue, não uma exigência literal dos exemplos de código dos PDFs. A lógica didática de JDBC, DAO, PreparedStatement, chaves estrangeiras e JOIN foi preservada.
