package br.com.techlab;

import br.com.techlab.config.ConexaoBanco;
import br.com.techlab.dao.AtivoDAO;
import br.com.techlab.dao.ChamadoDAO;
import br.com.techlab.model.AtivoTI;
import br.com.techlab.model.ChamadoSuporte;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Main {

    public static void main(String[] args) {
        try {
            ConexaoBanco.inicializarBanco();
            AtivoDAO ativoDAO = new AtivoDAO();
            ChamadoDAO chamadoDAO = new ChamadoDAO();

            // Patrimônio único para evitar conflito ao executar a demonstração novamente.
            String codigo = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
            AtivoTI novoAtivo = new AtivoTI("PAT-" + codigo,
                    "Notebook Dell Latitude", "Notebook",
                    "Windows 11 - 16 GB RAM", 4500.00);
            ativoDAO.salvar(novoAtivo);

            AtivoTI ativoSalvo = ativoDAO.buscarPorPatrimonio(novoAtivo.getPatrimonio())
                    .orElseThrow(() -> new IllegalStateException("Ativo não encontrado após cadastro."));

            System.out.println("\n--- ATIVOS CADASTRADOS ---");
            ativoDAO.listarTodos().forEach(System.out::println);

            ChamadoSuporte chamado = new ChamadoSuporte(
                    "Verificar lentidão e atualizar drivers", "ABERTO", ativoSalvo);
            chamadoDAO.salvar(chamado);

            ativoSalvo.setNome("Notebook Dell Latitude - atualizado");
            ativoSalvo.setValor(4700.00);
            System.out.println("\nAtivo atualizado? " + ativoDAO.atualizar(ativoSalvo));

            System.out.println("\n--- CHAMADOS COM DADOS DO ATIVO (INNER JOIN) ---");
            chamadoDAO.listarTodosComAtivo().forEach(System.out::println);

            System.out.println("\n--- TESTE DE INTEGRIDADE REFERENCIAL ---");
            try {
                boolean excluido = ativoDAO.excluir(ativoSalvo.getId());
                if (!excluido) {
                    System.out.println("Aviso: Nenhum ativo foi localizado com o ID informado. Exclusão não efetuada.");
                } else {
                    System.out.println("Ativo excluído.");
                }
            } catch (SQLException e) {
                System.out.println("Exclusão bloqueada: há chamados vinculados ao ativo.");
                System.out.println("Detalhe: " + e.getMessage());
            }

            // Limpeza da demonstração: primeiro o registro filho, depois o pai.
            System.out.println("\n--- LIMPEZA DOS DADOS DE TESTE ---");
            for (ChamadoSuporte item : chamadoDAO.listarPorAtivo(ativoSalvo.getId())) {
                chamadoDAO.excluir(item.getId());
            }
            boolean ativoRemovido = ativoDAO.excluir(ativoSalvo.getId());
            System.out.println("Chamados de teste removidos.");
            System.out.println("Ativo de teste removido? " + ativoRemovido);
            System.out.println("\nDemonstração concluída. O banco techlab.db permanece criado.");

        } catch (SQLException e) {
            System.err.println("[ERRO] Falha na operação com o banco: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
