# TechLab Inventory & Service Desk

Sistema didático de gerenciamento de ativos de TI e chamados de suporte, desenvolvido em Java 17 com JDBC e SQLite. Integra os conteúdos das Aulas 08 e 09.

## Funcionalidades
- Cadastro, listagem e busca de ativos por patrimônio.
- Atualização e exclusão de ativos com validação de linhas afetadas.
- Cadastro e consulta de chamados associados a ativos.
- Consulta de chamados com os dados completos do ativo usando `INNER JOIN`.
- Integridade referencial com chave estrangeira e `PRAGMA foreign_keys = ON`.
- `PreparedStatement`, `try-with-resources` e padrão DAO.

## Tecnologias
Java 17, Maven, JDBC, SQLite, Visual Studio Code, Git e GitHub.

## Estrutura
```text
techlab-inventory-service-desk/
├── documentacao/             # PDFs originais das Aulas 08 e 09
├── src/main/java/br/com/techlab/
│   ├── config/ConexaoBanco.java
│   ├── dao/AtivoDAO.java
│   ├── dao/ChamadoDAO.java
│   ├── model/AtivoTI.java
│   ├── model/ChamadoSuporte.java
│   └── Main.java
├── src/main/resources/schema.sql
├── TUTORIAL.md               # Tutorial explicado passo a passo
├── pom.xml
├── .gitignore
└── README.md
```

## Pré-requisitos
- JDK 17 ou superior.
- Visual Studio Code com **Extension Pack for Java**.
- Maven instalado e disponível no terminal.

O Maven baixa automaticamente o driver JDBC do SQLite, declarado no `pom.xml`. Não é necessário adicionar manualmente um arquivo `.jar`.

## Executar no VS Code
1. Extraia o ZIP.
2. Abra no VS Code a pasta do projeto, aquela que contém `pom.xml`.
3. Aguarde o Maven resolver as dependências.
4. Abra o terminal integrado nessa pasta e execute:

```bash
mvn clean compile
mvn exec:java -Dexec.mainClass="br.com.techlab.Main"
```

O arquivo local `techlab.db` será criado na raiz do projeto. Ele não deve ser enviado ao GitHub.

## Documentação
Consulte [`TUTORIAL.md`](TUTORIAL.md) para entender a estrutura, a conexão JDBC, as tabelas, o uso de PreparedStatement, try-with-resources, os DAOs, o JOIN, a execução e o envio ao GitHub. Os PDFs originais das aulas estão preservados em `documentacao/`.

## Relação com as aulas
- **Aula 08:** conexão JDBC, criação de tabelas, PreparedStatement, try-with-resources, DAO, cadastro, listagem e busca.
- **Aula 09:** CRUD, chave estrangeira, relacionamento entre ativos e chamados, validação de exclusão e consulta JOIN.

## Nota de consolidação
Os materiais apresentam versões diferentes de `AtivoTI`: a Aula 08 utiliza `categoria` e `detalhe_especifico`; a Aula 09 acrescenta `valor` e `status` no chamado. O projeto reúne os campos das duas etapas. A estrutura Maven e o pacote `br.com.techlab` foram adotados para facilitar a execução e manutenção no VS Code.
