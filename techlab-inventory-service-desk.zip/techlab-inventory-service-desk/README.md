# TechLab Inventory & Service Desk

Sistema didático de gerenciamento de ativos de TI e chamados de suporte, desenvolvido em Java com JDBC e SQLite. Reúne os conteúdos práticos das Aulas 08 e 09.

## Funcionalidades
- Cadastro, listagem, busca, atualização e exclusão de ativos.
- Abertura e consulta de chamados vinculados a ativos.
- Consulta de chamados com dados completos do ativo usando `INNER JOIN`.
- Proteção de integridade referencial: um ativo com chamados associados não pode ser excluído.
- `PreparedStatement`, `try-with-resources` e padrão DAO.

## Tecnologias
Java 17, Maven, JDBC, SQLite, Visual Studio Code, Git e GitHub.

## Estrutura
```text
techlab-inventory-service-desk/
├── documentacao/             # PDFs originais das Aulas 08 e 09
├── src/main/java/br/com/techlab/
│   ├── config/ConexaoBanco.java
│   ├── dao/AtivoDAO.java
│   ├── dao/ChamadoDAO.java
│   ├── model/AtivoTI.java
│   ├── model/ChamadoSuporte.java
│   └── Main.java
├── src/main/resources/schema.sql
├── pom.xml
├── .gitignore
└── README.md
```

## Pré-requisitos
- JDK 17 ou superior.
- Visual Studio Code com a extensão **Extension Pack for Java**.
- Maven instalado (ou suporte Maven habilitado no VS Code).

O Maven baixa automaticamente o driver JDBC do SQLite. Não é necessário adicionar manualmente um arquivo `.jar`.

## Executar no VS Code
1. Extraia o ZIP.
2. Abra a pasta do projeto no VS Code (`File > Open Folder`).
3. Aguarde o reconhecimento Maven e a resolução das dependências.
4. Abra o terminal integrado na pasta que contém `pom.xml` e execute:

```bash
mvn clean compile
mvn exec:java -Dexec.mainClass="br.com.techlab.Main"
```

O banco `techlab.db` será criado na raiz do projeto. Ele é local e está no `.gitignore`, portanto não será enviado ao GitHub.

## Sobre a demonstração
A classe `Main` cadastra um ativo com patrimônio único por execução, abre um chamado associado, atualiza o ativo, lista os chamados com `JOIN` e demonstra a restrição de exclusão. Os registros de demonstração são mantidos no banco local para que você possa consultá-los depois.

## Enviar para o GitHub
Crie um repositório vazio no GitHub. No terminal, dentro da pasta do projeto, execute:

```bash
git init
git add .
git commit -m "feat: estrutura inicial do TechLab Inventory"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/techlab-inventory-service-desk.git
git push -u origin main
```

Troque `SEU-USUARIO` pelo seu usuário do GitHub.

Se você já clonou um repositório para o computador, copie os arquivos para dentro dele e não repita `git init` ou `git remote add origin`.

## Relação com as aulas
- **Aula 08:** conexão JDBC, criação das tabelas, PreparedStatement, try-with-resources e DAO.
- **Aula 09:** CRUD, chaves estrangeiras, relacionamento entre ativos e chamados e consultas JOIN.

Os PDFs originais estão preservados em `documentacao/`.

## Nota de organização
Os dois materiais apresentam versões diferentes do modelo `AtivoTI`. Para consolidá-los, este projeto contempla os campos `categoria`, `detalheEspecifico` e `valor` no mesmo modelo. A organização Maven e a estrutura em pacotes foram adotadas para facilitar a execução e a manutenção no VS Code.
