# Materiais de apoio

Os PDFs originais das atividades práticas foram preservados nesta pasta:

- `Aula-08-JDBC.pdf`: introdução ao JDBC, conexão, PreparedStatement, try-with-resources e DAO.
- `Aula-09-CRUD.pdf`: operações CRUD, chaves estrangeiras, relacionamento entre ativos e chamados e consultas JOIN.

Os documentos não foram alterados.
