package br.com.techlab.dao;

import br.com.techlab.config.ConexaoBanco;
import br.com.techlab.model.AtivoTI;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AtivoDAO {

    public void salvar(AtivoTI ativo) throws SQLException {
        String sql = """
                INSERT INTO ativos (patrimonio, nome, categoria, detalhe_especifico, valor)
                VALUES (?, ?, ?, ?, ?)
                """;
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, ativo.getPatrimonio());
            stmt.setString(2, ativo.getNome());
            stmt.setString(3, ativo.getCategoria());
            stmt.setString(4, ativo.getDetalheEspecifico());
            stmt.setDouble(5, ativo.getValor());
            stmt.executeUpdate();
        }
    }

    public List<AtivoTI> listarTodos() throws SQLException {
        String sql = """
                SELECT id, patrimonio, nome, categoria, detalhe_especifico, valor
                FROM ativos ORDER BY id ASC
                """;
        List<AtivoTI> lista = new ArrayList<>();
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) lista.add(mapear(rs));
        }
        return lista;
    }

    public Optional<AtivoTI> buscarPorPatrimonio(String patrimonio) throws SQLException {
        String sql = """
                SELECT id, patrimonio, nome, categoria, detalhe_especifico, valor
                FROM ativos WHERE patrimonio = ?
                """;
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, patrimonio);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }
        }
        return Optional.empty();
    }

    public boolean atualizar(AtivoTI ativo) throws SQLException {
        String sql = """
                UPDATE ativos
                SET patrimonio = ?, nome = ?, categoria = ?, detalhe_especifico = ?, valor = ?
                WHERE id = ?
                """;
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, ativo.getPatrimonio());
            stmt.setString(2, ativo.getNome());
            stmt.setString(3, ativo.getCategoria());
            stmt.setString(4, ativo.getDetalheEspecifico());
            stmt.setDouble(5, ativo.getValor());
            stmt.setInt(6, ativo.getId());
            return stmt.executeUpdate() > 0;
        }
    }

    public boolean excluir(int id) throws SQLException {
        String sql = "DELETE FROM ativos WHERE id = ?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }

    private AtivoTI mapear(ResultSet rs) throws SQLException {
        return new AtivoTI(rs.getInt("id"), rs.getString("patrimonio"),
                rs.getString("nome"), rs.getString("categoria"),
                rs.getString("detalhe_especifico"), rs.getDouble("valor"));
    }
}
