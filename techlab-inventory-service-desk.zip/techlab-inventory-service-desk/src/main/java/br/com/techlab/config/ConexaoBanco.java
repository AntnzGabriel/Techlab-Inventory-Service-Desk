package br.com.techlab.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public final class ConexaoBanco {
    private static final String URL = "jdbc:sqlite:techlab.db";

    private ConexaoBanco() {}

    public static Connection obterConexao() throws SQLException {
        Connection conexao = DriverManager.getConnection(URL);
        try (Statement stmt = conexao.createStatement()) {
            // O SQLite exige habilitar a verificação de FK em cada conexão.
            stmt.execute("PRAGMA foreign_keys = ON;");
            return conexao;
        } catch (SQLException e) {
            conexao.close();
            throw e;
        }
    }

    public static void inicializarBanco() throws SQLException {
        String sqlAtivos = """
                CREATE TABLE IF NOT EXISTS ativos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    patrimonio TEXT NOT NULL UNIQUE,
                    nome TEXT NOT NULL,
                    categoria TEXT NOT NULL,
                    detalhe_especifico TEXT,
                    valor REAL NOT NULL DEFAULT 0
                )
                """;
        String sqlChamados = """
                CREATE TABLE IF NOT EXISTS chamados (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    descricao TEXT NOT NULL,
                    status TEXT NOT NULL,
                    ativo_id INTEGER NOT NULL,
                    FOREIGN KEY (ativo_id) REFERENCES ativos(id) ON DELETE RESTRICT
                )
                """;

        try (Connection conexao = obterConexao();
             Statement stmt = conexao.createStatement()) {
            stmt.execute(sqlAtivos);
            stmt.execute(sqlChamados);
            System.out.println("[INFO] Banco de dados inicializado.");
        }
    }
}
