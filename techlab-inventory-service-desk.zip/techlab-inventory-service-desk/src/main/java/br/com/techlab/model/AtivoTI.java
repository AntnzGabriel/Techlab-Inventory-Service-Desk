package br.com.techlab.model;

public class AtivoTI {
    private int id;
    private String patrimonio;
    private String nome;
    private String categoria;
    private String detalheEspecifico;
    private double valor;

    public AtivoTI(String patrimonio, String nome, String categoria,
                   String detalheEspecifico, double valor) {
        this(0, patrimonio, nome, categoria, detalheEspecifico, valor);
    }

    public AtivoTI(int id, String patrimonio, String nome, String categoria,
                   String detalheEspecifico, double valor) {
        this.id = id;
        this.patrimonio = patrimonio;
        this.nome = nome;
        this.categoria = categoria;
        this.detalheEspecifico = detalheEspecifico;
        this.valor = valor;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getPatrimonio() { return patrimonio; }
    public void setPatrimonio(String patrimonio) { this.patrimonio = patrimonio; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }
    public String getDetalheEspecifico() { return detalheEspecifico; }
    public void setDetalheEspecifico(String detalheEspecifico) { this.detalheEspecifico = detalheEspecifico; }
    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }

    @Override
    public String toString() {
        return String.format(
                "AtivoTI{id=%d, patrimonio='%s', nome='%s', categoria='%s', detalhe='%s', valor=R$ %.2f}",
                id, patrimonio, nome, categoria, detalheEspecifico, valor);
    }
}
