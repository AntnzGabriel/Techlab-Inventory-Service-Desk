package br.com.techlab.dao;

import br.com.techlab.config.ConexaoBanco;
import br.com.techlab.model.AtivoTI;
import br.com.techlab.model.ChamadoSuporte;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ChamadoDAO {

    public void salvar(ChamadoSuporte chamado) throws SQLException {
        if (chamado.getAtivo() == null || chamado.getAtivo().getId() <= 0) {
            throw new IllegalArgumentException("O chamado precisa estar associado a um ativo já salvo.");
        }
        String sql = "INSERT INTO chamados (descricao, status, ativo_id) VALUES (?, ?, ?)";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setString(1, chamado.getDescricao());
            stmt.setString(2, chamado.getStatus());
            stmt.setInt(3, chamado.getAtivo().getId());
            stmt.executeUpdate();
        }
    }

    public List<ChamadoSuporte> listarPorAtivo(int ativoId) throws SQLException {
        String sql = "SELECT id, descricao, status, ativo_id FROM chamados WHERE ativo_id = ? ORDER BY id";
        List<ChamadoSuporte> lista = new ArrayList<>();
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, ativoId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    AtivoTI referencia = new AtivoTI(rs.getInt("ativo_id"),
                            null, null, null, null, 0);
                    lista.add(new ChamadoSuporte(rs.getInt("id"),
                            rs.getString("descricao"), rs.getString("status"), referencia));
                }
            }
        }
        return lista;
    }

    public List<ChamadoSuporte> listarTodosComAtivo() throws SQLException {
        String sql = """
                SELECT c.id AS chamado_id, c.descricao, c.status,
                       a.id AS ativo_id, a.patrimonio, a.nome, a.categoria,
                       a.detalhe_especifico, a.valor
                FROM chamados c
                INNER JOIN ativos a ON c.ativo_id = a.id
                ORDER BY c.id
                """;
        List<ChamadoSuporte> lista = new ArrayList<>();
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                AtivoTI ativo = new AtivoTI(rs.getInt("ativo_id"),
                        rs.getString("patrimonio"), rs.getString("nome"),
                        rs.getString("categoria"), rs.getString("detalhe_especifico"),
                        rs.getDouble("valor"));
                lista.add(new ChamadoSuporte(rs.getInt("chamado_id"),
                        rs.getString("descricao"), rs.getString("status"), ativo));
            }
        }
        return lista;
    }

    public boolean excluir(int id) throws SQLException {
        String sql = "DELETE FROM chamados WHERE id = ?";
        try (Connection conexao = ConexaoBanco.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        }
    }
}
