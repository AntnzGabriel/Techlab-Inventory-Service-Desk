package br.com.techlab.model;

public class ChamadoSuporte {
    private int id;
    private String descricao;
    private String status;
    private AtivoTI ativo;

    public ChamadoSuporte(String descricao, String status, AtivoTI ativo) {
        this(0, descricao, status, ativo);
    }

    public ChamadoSuporte(int id, String descricao, String status, AtivoTI ativo) {
        this.id = id;
        this.descricao = descricao;
        this.status = status;
        this.ativo = ativo;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public AtivoTI getAtivo() { return ativo; }
    public void setAtivo(AtivoTI ativo) { this.ativo = ativo; }

    @Override
    public String toString() {
        String nomeAtivo = ativo == null ? "não informado" : ativo.getNome();
        return String.format("ChamadoSuporte{id=%d, descricao='%s', status='%s', ativo='%s'}",
                id, descricao, status, nomeAtivo);
    }
}
